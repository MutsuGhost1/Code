
public interface MailService {
    public void send(String str);
}
