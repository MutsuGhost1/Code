
public interface MailService {
    public void send(Message msg);
}
