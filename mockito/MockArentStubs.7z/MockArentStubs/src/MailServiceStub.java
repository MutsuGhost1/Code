import java.util.ArrayList;
import java.util.List;


public class MailServiceStub implements MailService {
    private List<Message> mMessages = new ArrayList<Message>();
    @Override
    public void send(Message msg) {
        mMessages.add(msg);
    }

    public int numberSent(){
        return mMessages.size();
    }
}
