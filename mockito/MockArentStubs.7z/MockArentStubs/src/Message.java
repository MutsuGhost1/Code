
public class Message {
    public Message(String strContent){
        
    }
}
