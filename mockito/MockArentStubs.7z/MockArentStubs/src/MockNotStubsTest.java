import junit.framework.TestCase;

public class MockNotStubsTest extends TestCase {

    public void testOrderSendsMailIfUnfilledUsingStub(){
        
    }

    public void testOrderSendsMailIfUnfilledUsingMock(){
        
    }
}
