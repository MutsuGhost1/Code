
public class Order {
    String mName;
    int mNum;
    
    public Order(String name, int num){
        mName = name;
        mNum = num;
    }
    
    public void fill(){
        
    }
    
    public boolean isFilled(){
        return 0 == mNum;
    }
}
