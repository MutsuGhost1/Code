
public class Warehouse {
    private MailService mMail;
    
    public boolean hasInventory(String name, int num){
        if("Talisker".equals(name)
        && 50 >= num){
            return true;
        }
        mMail.send(new Message(name + ":" + num + " is not enough!"));
        return false;
    }
    
    public void setMailer(MailService mail){
        mMail = mail;
    }
}
