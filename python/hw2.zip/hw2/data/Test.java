

public class Test{
    
    static public void main(String[] argv){
        int _id1 = 10, $id2 = 20;
        
    }
    
    static void �o�O�@�Ӥ����k(){
    
    }
    
    public Test(){
  	
    }
    
    public static int �����k1 (     
    )
    
    
    {
    	return 0;
    }
 
    public
    static
    void
    �����k2
    ()
    {}

    public static < T , 
    S extends 
    T 
    > void copy(java.util.List<T> dest, java.util.List<S> src)
    {
    	
    }
    
    
}