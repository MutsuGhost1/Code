#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Administrator
#
# Created:     05/10/2013
# Copyright:   (c) Administrator 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import os, re, mmap, contextlib, types, codecs

_DEBUG = True

# nested comment is forbidden in java
def removeAllJavaComments(mmapData):
    listPattern = [re.compile("(/\*)(.*?)(\*/)",re.DOTALL ), re.compile("(//.*?\n)" )]
    # process all patterns
    for pattern in listPattern:
        # 1. find all match string of the pattern in mmap
        allMatchResults = re.findall(pattern, mmapData)
        if _DEBUG: print "type: " + str(type(allMatchResults)) + " allMatchResults:" + str(allMatchResults)
        # reset the file position for each replacement
        mmapData.seek(0)
        if 0 != len(allMatchResults):
            for match in allMatchResults:
                if type(match) is types.TupleType:
                    matchStr = "".join(match)
                else:
                    matchStr = match.rstrip()
        # 2. delete all match string of the pattern in mmap
                if _DEBUG: print "matchStr:" + matchStr
                pos = mmapData.find(matchStr)
                if _DEBUG: print "position=" + str(pos)
                if _DEBUG: print "mmapData[pos:len(matchStr)]:" + mmapData[pos:pos+len(matchStr)]
                # replace match string as white space
                mmapData[pos:pos+len(matchStr)] = " " * len(matchStr)
        if _DEBUG: print "All:" + mmapData.read(1024**2)
    return mmapData

def testIdentifier(mmapData):

    re_identifier = r"((public\s+|static\s+)+)([^']*?)(\b[\w$]+\s*)(\([^']*?\))"
    allMatchResults = re.findall(re.compile(re_identifier, re.UNICODE), mmapData)
    if 0 != len(allMatchResults):
        for match in allMatchResults:
            print str(match)
            if type(match) is types.TupleType:
                matchStr = "".join(match)
            else:
                matchStr = match.rstrip()
#            matchStr.decode("utf8")
#            if _DEBUG: print "matchStr:" + matchStr


def methodCount(filePath):
    if not os.path.isfile(filePath):
        raise StandardError("invalud file path: " + filePath)

    encoding = "big5"
    with open(filePath, mode="rb") as f:
        peekBytes = min(32, os.path.getsize(filePath))
        rawData = f.read(peekBytes)
        if rawData.startswith(codecs.BOM_UTF8):
            encoding = "utf-8"
        elif rawData.startswith(codecs.BOM_UTF16_LE):
            encoding = "utf-16"
        else:
            encoding = "big5"
        print "encoding:" + encoding

    with codecs.open(filePath, mode="r+", encoding=encoding) as f:
        buffer = f.read()
        print repr(f.read())
        with contextlib.closing(mmap.mmap(f.fileno(), 0)) as m:
            if _DEBUG: print "Content:\n" + m.read(1024**2)
            # m = removeAllJavaComments(m)
            testIdentifier(buffer)

def main():
#    methodCount(r"E:\Temp\Python\hw2\comments.txt")
#    methodCount(r"E:\Temp\Python\hw2\identifier.txt")
    methodCount(r"E:\Temp\TestUtf16.java")
if __name__ == '__main__':
    main()
