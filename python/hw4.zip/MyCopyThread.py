#-------------------------------------------------------------------------------
# Name:        MyCopy.py
# Purpose:     hw4
#
# Author:      Administrator
#
# Created:     04/11/2013
# Copyright:   (c) Administrator 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import wx
import Queue
import threading
import multiprocessing
import logging
import os
import sys
import shutil
import time

DEBUG_FLAG = False

class ProgressCounter (object):
    def __init__(self, end=100, start=0):
        self.start = start
        self.end = end
        self.lock = multiprocessing.RLock()
    def __del__(self):
        del self.lock
    def setRange(self, end):
        self.lock.acquire()
        self.end = end
        self.lock.release()
    def incProgress(self):
        self.lock.acquire()
        self.start += 1
        self.lock.release()
    def curProgress(self):
        self.lock.acquire()
        val = self.start*100/self.end
        self.lock.release()
        return val
    def isComplete(self):
        bComplete = False
        self.lock.acquire()
        bComplete = self.end == self.start
        self.lock.release()
        return bComplete

def consumerRunner(taskQueue, counter):
    while True:
        if DEBUG_FLAG: print "taskQueue.qsize()=%d" % (taskQueue.qsize())
        next_task = taskQueue.get(False)
        if next_task is None:
            if DEBUG_FLAG: print "exit"
            break
        filePath, destPath = next_task
        try:
            if os.path.isdir(filePath):
                prefix, tail = os.path.split(filePath)
                folderPath = os.path.join(destPath,tail)
                if not os.path.exists(folderPath):
                    if DEBUG_FLAG: print "create directory (" + folderPath + ")"
                    if DEBUG_FLAG: sys.stdout.flush()
                    os.mkdir(folderPath)
            else:
                if DEBUG_FLAG: print "copy file (" + filePath +") to (" + destPath + ")"
                if DEBUG_FLAG: sys.stdout.flush()
                try:
                    if not os.path.exists(destPath):
                        if DEBUG_FLAG: print "dest directort doesn't exists, create it %s" % (destPath)
                        if DEBUG_FLAG: sys.stdout.flush()
                        os.mkdir(destPath)
                except Exception as e:
                    if DEBUG_FLAG: print "Exception: (create directory %s when copying file)" % (destPath)
                shutil.copy(filePath, destPath)
        except Exception as e:
            if DEBUG_FLAG: print "Exception: %s" %(e)
        finally:
            counter.incProgress()
    if DEBUG_FLAG: sys.stdout.flush()

def producerRunner(taskQueue, srcFolder, destFolder, consumerNum, counter):
    if os.path.isdir(srcFolder):
        itemNum = 0
        for dirPath, dirNames, fileNames  in os.walk(srcFolder):
            tailFolder = dirPath.replace(srcFolder,"")
            destPath = destFolder + tailFolder
            if DEBUG_FLAG: print "destPath=" + destPath

            for dirName in dirNames:
                folderPath = os.path.join(dirPath,dirName)
                if DEBUG_FLAG: print "put item: folderPath=%s destPath=%s" % (folderPath, destPath)
                # a tuple (srcFilePath, destFolderPath)
                taskQueue.put((folderPath, destPath))
                itemNum += 1

            for fileName in fileNames:
                filePath = os.path.join(dirPath,fileName)
                if DEBUG_FLAG: print "put item: filePath=%s destPath=%s" % (filePath, destPath)
                # a tuple (srcFilePath, destFolderPath)
                taskQueue.put((filePath, destPath))
                itemNum += 1
            if DEBUG_FLAG: print ""
            counter.setRange(itemNum)
    else:
        if DEBUG_FLAG: print srcFolder + " is not a folder"
    for i in xrange(consumerNum):
        if DEBUG_FLAG: print "start to put (%d) None" % (i+1)
        taskQueue.put(None)
    if DEBUG_FLAG: print "taskQueue: %d" % taskQueue.qsize()
    if DEBUG_FLAG: sys.stdout.flush()


def updateProgress(counter, consumers):
    while not counter.isComplete():
        print "Copy Progress %d %%" % (counter.curProgress())
        if DEBUG_FLAG:
            for c in consumers:
                print "%s: is_alive=%s" % (c.name, c.is_alive())
        sys.stdout.flush()
        time.sleep(0.1)
    if DEBUG_FLAG:
       for c in consumers:
            print "%s: is_alive=%s" % (c.name, c.is_alive())
    print "Copy Progress %d %%" % (counter.curProgress())
    sys.stdout.flush()

def copyDir(srcPath, destPath, counter, parallelNum):
    if os.path.isdir(srcPath):
        if os.path.isabs(destPath):
            if not os.path.isdir(destPath):
                os.makedirs(destPath)
        else:
            print "destPath %s is not a legal path!" % (destPath)


        taskQueue = Queue.Queue()
        tProducer = threading.Thread(target = producerRunner, args=(taskQueue, srcPath, destPath, parallelNum, counter))
        if DEBUG_FLAG: print "tProducer.start() start"
        tProducer.start()
        if DEBUG_FLAG: print "tProducer.wait() start"
        tProducer.join()

        consumers = []
        for i in xrange(parallelNum):
            consumers.append(threading.Thread(target = consumerRunner, args=(taskQueue, counter)))

        if DEBUG_FLAG: print "tConsumer.start() start"
        for tConsumer in consumers:
            tConsumer.start()

        # create thread to update progress
        tProgress =threading.Thread(target=updateProgress, args=(counter, consumers))
        if DEBUG_FLAG: print "tProgress.start() start"
        tProgress.start()

        # wait processes & threads to be finished
        if DEBUG_FLAG: print "tConsumer.join() tProgress.join() start"
        for tConsumer in consumers:
            tConsumer.join()
        tProgress.join()

        if DEBUG_FLAG: print "main thread exit"
        if DEBUG_FLAG: sys.stdout.flush()
    else:
        print "srcPath %s is not a legal path!" % (srcPath)

def main(argv):
    if 2 < len(argv):
        srcPath   = argv[1]
        destPath  = argv[2]

        if not os.path.isdir(srcPath) or not os.path.isdir(destPath):
            print "MyCopyThread.py [absolute src folder path] [absolute dest folder path]!"
            return

        numThread = 5
        if 3 < len(argv):
            try:
                numThread = int(argv[3])
            except:
                numThread = 5
        copyDir(srcPath, destPath, ProgressCounter(), numThread)

if __name__ == '__main__':
    main(sys.argv)
