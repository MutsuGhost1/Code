#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Administrator
#
# Created:     31/12/2013
# Copyright:   (c) Administrator 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import os, sys, pickle, tempfile, urlparse, json
from BaseHTTPServer import HTTPServer
from BaseHTTPServer import BaseHTTPRequestHandler

def getAFileName(strDir=None):
    if None != strDir:
        assert(os.path.isdir(strDir))
        pass
    tmpFile = tempfile.TemporaryFile(dir=strDir)
    strFileName = tmpFile.name
    tmpFile.close()
    return strFileName

class GetPostHandler(BaseHTTPRequestHandler):
    # override
    def do_HEAD(self, retCode=200):
        self.send_response(retCode)
        self.send_header("Content-type", "text/html")
        self.end_headers()

    # override
    def do_POST(self):
        strFolderName = "Log"

        self.do_HEAD()

        contentLen = int(self.headers.getheader("content-length"))
        strData = self.rfile.read(contentLen)
        dictData = json.loads(strData)

        if not os.path.isdir(strFolderName):
            os.mkdir(strFolderName)

        strFileName = getAFileName(strFolderName)
        with open(strFileName, "w+") as file:
            pickle.dump(dictData, file)

        if not os.path.exists(strFileName):
            strPath = ""
        else:
            strPath = strFileName[strFileName.rfind(strFolderName+os.path.sep):]

        self.wfile.write(strPath)

    # override
    def do_GET(self):
        self.do_HEAD()

        parsedUrl = urlparse.urlparse(self.path)
        strPath = os.getcwd() + parsedUrl.path

        if not os.path.exists(strPath):
            self.wfile.write(self.getErrorMsg())
        else:
            with open(strPath, "r+") as file:
                dictData = pickle.load(file)
            self.wfile.write(self.getFormatMsg(dictData))

    def getErrorMsg(self):
        return "<html><head><title>Error</title></head><body><p>NO SUCH RECORD</p></body></html>"

    def getFormatMsg(self, dictData):
        assert(isinstance(dictData, dict))
        strHead = "<html><head><title>Build Result</title></head><body>"

        strBody = ""
        for key in dictData.keys():
            strBody = strBody + "<center><h1> %s:%s </h1></center><br>" %(key, dictData[key])

        strTail = "</body></html>"
        return strHead + strBody + strTail

def main(argv):
    try:
        httpdServer = HTTPServer(('localhost', 8192), GetPostHandler)
        print 'Starting server, use <Ctrl-C> to stop'
        httpdServer.serve_forever()
    except KeyboardInterrupt:
        pass

if '__main__' == __name__:
    main(sys.argv)
